#include "fibs1.c"
#include "fibs2.c"